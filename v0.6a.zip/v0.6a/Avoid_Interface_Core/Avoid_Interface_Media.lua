
local LSM = LibStub and LibStub("LibSharedMedia-3.0", true)
if not LSM then
    return
end

local FONT_PATH = "Interface\\AddOns\\Avoid_Interface_Core\\Media\\Fonts\\"

LSM:Register(
    "font",
    "Ubuntu Regular",                         -- so heißt der Font im Dropdown
    FONT_PATH .. "Ubuntu-Regular.ttf"         -- Dateiname im Fonts-Ordner
)

LSM:Register(
    "font",
    "Ubuntu Bold",
    FONT_PATH .. "Ubuntu-Bold.ttf"
)
