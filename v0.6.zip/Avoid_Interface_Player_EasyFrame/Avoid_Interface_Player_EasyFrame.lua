-- Avoid_Interface_Player_EasyFrame.lua
-- EasyFrame für Player-Mitglieder (Player1-4), an den Player-EasyFrame angelehnt

local addonName, ns = ...

AI        = AI or {}
AI.modules = AI.modules or {}
AI_Config = AI_Config or {}

local M = {}
AI.modules.player = M

-- Optional: LibSharedMedia-3.0 für zusätzliche Fonts
local LSM = LibStub and LibStub("LibSharedMedia-3.0", true)
-------------------------------------------------
-- SharedMedia / Textur-Auswahl
-------------------------------------------------

local BAR_TEXTURE_DEFAULT    = "Interface\\TARGETINGFRAME\\UI-StatusBar"
local BORDER_TEXTURE_DEFAULT = "Interface\\Tooltips\\UI-Tooltip-Border"

local function GetPlayerEntry()
    AI_Config          = AI_Config or {}
    AI_Config.modules  = AI_Config.modules or {}
    AI_Config.modules.player = AI_Config.modules.player or {}

    -- Defaults, falls noch nichts gespeichert wurde
    if AI_Config.modules.player.barTextureKey == nil then
        AI_Config.modules.player.barTextureKey = "DEFAULT"
    end
    if AI_Config.modules.player.borderTextureKey == nil then
        AI_Config.modules.player.borderTextureKey = "DEFAULT"
    end

    return AI_Config.modules.player
end

local function GetPlayerBarTexture()
    local entry = GetPlayerEntry()
    local key   = entry.barTextureKey or "DEFAULT"

    if key ~= "DEFAULT" and LSM then
        local tex = LSM:Fetch("statusbar", key)
        if tex then
            return tex
        end
    end

    return BAR_TEXTURE_DEFAULT
end

local function GetPlayerBorderTexture()
    local entry = GetPlayerEntry()
    local key   = entry.borderTextureKey or "DEFAULT"

    if key ~= "DEFAULT" and LSM then
        local tex = LSM:Fetch("border", key)
        if tex then
            return tex
        end
    end

    return BORDER_TEXTURE_DEFAULT
end

-- wendet die Texturen auf einen fertigen Player-Frame an
local function ApplyMediaToPlayerFrame(frame)
    if not frame then return end

    local barTex    = GetPlayerBarTexture()
    local borderTex = GetPlayerBorderTexture()

    -- Statusbars
    if frame.healthBar and frame.healthBar.SetStatusBarTexture then
        frame.healthBar:SetStatusBarTexture(barTex)
    end
    if frame.powerBar and frame.powerBar.SetStatusBarTexture then
        frame.powerBar:SetStatusBarTexture(barTex)
    end
    if frame.absorbBar and frame.absorbBar.SetStatusBarTexture then
        frame.absorbBar:SetStatusBarTexture(barTex)
    end

    -- Rahmen / Border
    -- passe das an deine echten Frame-Namen an (backdrop, borderFrame, etc.)
    local backdropOwner = frame.backdrop or frame.Border or frame

    if backdropOwner and backdropOwner.SetBackdrop then
        local bd = backdropOwner:GetBackdrop() or {}

        bd.bgFile   = bd.bgFile   or "Interface\\ChatFrame\\ChatFrameBackground"
        bd.edgeFile = borderTex
        bd.edgeSize = bd.edgeSize or 12
        bd.insets   = bd.insets   or { left = 3, right = 3, top = 3, bottom = 3 }

        backdropOwner:SetBackdrop(bd)
    end
end

-- wird von außen benutzt, um alle Playerframes neu zu skinnen
function M.RefreshMedia()
    if not frames then return end
    for _, f in pairs(frames) do
        ApplyMediaToPlayerFrame(f)
    end
end

-------------------------------------------------
-- Konstanten / Tabellen
-------------------------------------------------
local Player_UNITS = { "player" }
local Player_UNIT_LOOKUP = {
    player = true
}

-------------------------------------------------
-- Hilfsfunktion: sicher prüfen, ob wir im Combat-Lockdown sind
-------------------------------------------------
local function IsInLockdown()
    return InCombatLockdown and InCombatLockdown() or false
end
-- -- Alias für Stellen, die bereits InLockdown() aufrufen
-- local function InLockdown()
--     return IsInLockdown()
-- end
local BAR_TEXTURES = {
    DEFAULT = "Interface\\TARGETINGFRAME\\UI-StatusBar",
    RAID    = "Interface\\RaidFrame\\Raid-Bar-Hp-Fill",
    FLAT    = "Interface\\Buttons\\WHITE8x8",

    -- neue Keys müssen zu texItems.value passen:
    SMOOTH  = "Interface\\RaidFrame\\Raid-Bar-Resource-Fill",
    GLASS   = "Interface\\PaperDollInfoFrame\\UI-Character-Skills-Bar",

    -- NEU: Absorb-Overlay (weißer Balken)
    ABSORB  = "Interface\\Buttons\\WHITE8x8",
}

local Player_PRESETS = {
    ["Default"] = {
        width       = 220,
        height      = 60,
        hpRatio     = 0.66,
        alpha       = 1.0,
        manaEnabled = true,

        frameBgMode = "OFF",    -- OFF, CLASS, CLASSPOWER

        hpColorMode     = "CLASS",    -- CLASS oder DEFAULT
        hpTexture       = "DEFAULT",
        mpTexture       = "DEFAULT",
        hpTextMode      = "BOTH",     -- BOTH oder PERCENT
        mpTextMode      = "BOTH",

        borderEnabled   = true,
        borderStyle     = "PIXEL",    -- PIXEL, THIN, THICK, TOOLTIP, DIALOG
        borderSize      = 1,
    },

    ["Compact"] = {
        width       = 180,
        height      = 44,
        hpRatio     = 0.6,
        alpha       = 1.0,
        manaEnabled = true,

        frameBgMode = "CLASS",

        hpColorMode     = "CLASS",
        hpTexture       = "RAID",
        mpTexture       = "FLAT",
        hpTextMode      = "PERCENT",
        mpTextMode      = "PERCENT",

        borderEnabled   = true,
        borderStyle     = "TOOLTIP",
        borderSize      = 1,
    },

    ["Healer"] = {
        width       = 240,
        height      = 52,
        hpRatio     = 0.7,
        alpha       = 1.0,
        manaEnabled = true,

        frameBgMode = "CLASSPOWER",

        hpColorMode     = "CLASS",
        hpTexture       = "SMOOTH",
        mpTexture       = "SMOOTH",
        hpTextMode      = "BOTH",
        mpTextMode      = "BOTH",

        borderEnabled   = true,
        borderStyle     = "PIXEL",
        borderSize      = 1,
    },
}

-------------------------------------------------
-- SavedVariables / Config
-------------------------------------------------

local function GetPlayerConfig()
    AI_Config = AI_Config or {}
    AI_Config.modules = AI_Config.modules or {}

    local cfg = AI_Config.modules.player
    if type(cfg) ~= "table" then
        cfg = {}
        AI_Config.modules.player = cfg
    end

    if cfg.enabled == nil then
        cfg.enabled = true
    end

    -- Grundgröße / Layout
    cfg.width       = cfg.width       or 220
    cfg.height      = cfg.height      or 60
    cfg.hpRatio     = cfg.hpRatio     or 0.66
    cfg.alpha       = cfg.alpha       or 1.0
    cfg.manaEnabled = (cfg.manaEnabled ~= false)

    -- Frame-Hintergrund
    if cfg.frameBgMode ~= "OFF" and cfg.frameBgMode ~= "CLASS" and cfg.frameBgMode ~= "CLASSPOWER" then
        cfg.frameBgMode = "OFF"
    end

    -- Bar-Farben / Texturen
    cfg.hpColorMode = cfg.hpColorMode or "CLASS"   -- CLASS oder DEFAULT
    cfg.hpTexture   = cfg.hpTexture   or "DEFAULT"
    cfg.mpTexture   = cfg.mpTexture   or "DEFAULT"

    -- Gültige Textmodi: BOTH, PERCENT, CUR
    local validTextModes = {
        BOTH            = true,
        BOTHSHORT       = true,
        PERCENT         = true,
        CUR             = true,
        CURSHORT        = true,
    }

    -- Globale Font-Settings: nur Default setzen, nichts "wegvalidieren"
    if not cfg.fontFace or cfg.fontFace == "" then
        cfg.fontFace = "DEFAULT"
    end

    if not cfg.fontOutline or cfg.fontOutline == "" then
        cfg.fontOutline = "NONE"
    end

    if not validTextModes[cfg.hpTextMode] then
        cfg.hpTextMode = "BOTH"
    end

    if not validTextModes[cfg.mpTextMode] then
        cfg.mpTextMode = "BOTH"
    end

    if cfg.hpUseCustomColor == nil then cfg.hpUseCustomColor = false end
    cfg.hpCustomColor = cfg.hpCustomColor or { r = 0, g = 1, b = 0 }

    if cfg.mpUseCustomColor == nil then cfg.mpUseCustomColor = false end
    cfg.mpCustomColor = cfg.mpCustomColor or { r = 0, g = 0, b = 1 }

    -- NEU: Farben für Absorb-Bar und verlorene HP
    cfg.absorbColor = cfg.absorbColor or { r = 1, g = 1, b = 1, a = 0.35 }
    cfg.hpLossColor = cfg.hpLossColor or { r = 0, g = 0, b = 0, a = 0.6 }    -- NEU: Farbe für HealAbsorb-Bar
    cfg.healAbsorbColor = cfg.healAbsorbColor or { r = 1, g = 0.8, b = 0, a = 0.8 }


    -- Textfarben
    cfg.nameTextColor  = cfg.nameTextColor  or { r = 1, g = 1, b = 1 }
    cfg.hpTextColor    = cfg.hpTextColor    or { r = 1, g = 1, b = 1 }
    cfg.mpTextColor    = cfg.mpTextColor    or { r = 1, g = 1, b = 1 }
    cfg.levelTextColor = cfg.levelTextColor or { r = 1, g = 1, b = 1 }

    cfg.nameTextUseClassColor  = cfg.nameTextUseClassColor  or false
    cfg.hpTextUseClassColor    = cfg.hpTextUseClassColor    or false
    cfg.mpTextUseClassColor    = cfg.mpTextUseClassColor    or false
    cfg.levelTextUseClassColor = cfg.levelTextUseClassColor or false

    -- Textsichtbarkeit / Größe / Anker
    cfg.showName      = (cfg.showName      ~= false)
    cfg.showHPText    = (cfg.showHPText    ~= false)
    cfg.showMPText    = (cfg.showMPText    ~= false)
    cfg.showLevelText = (cfg.showLevelText ~= false)

    cfg.nameSize      = cfg.nameSize      or 14
    cfg.hpTextSize    = cfg.hpTextSize    or 12
    cfg.mpTextSize    = cfg.mpTextSize    or 12
    cfg.levelTextSize = cfg.levelTextSize or 12

    cfg.nameAnchor   = cfg.nameAnchor   or "TOPLEFT"
    cfg.hpTextAnchor = cfg.hpTextAnchor or "BOTTOMRIGHT"
    cfg.mpTextAnchor = cfg.mpTextAnchor or "BOTTOMRIGHT"
    cfg.levelAnchor  = cfg.levelAnchor  or "BOTTOMLEFT"

    cfg.nameXOffset   = cfg.nameXOffset   or 0
    cfg.nameYOffset   = cfg.nameYOffset   or 0
    cfg.hpTextXOffset = cfg.hpTextXOffset or 0
    cfg.hpTextYOffset = cfg.hpTextYOffset or 0
    cfg.mpTextXOffset = cfg.mpTextXOffset or 0
    cfg.mpTextYOffset = cfg.mpTextYOffset or 0
    cfg.levelXOffset  = cfg.levelXOffset  or 0
    cfg.levelYOffset  = cfg.levelYOffset  or 0

    cfg.nameBold      = cfg.nameBold      or false
    if cfg.nameShadow == nil then cfg.nameShadow = true end
    cfg.hpTextBold    = cfg.hpTextBold    or false
    if cfg.hpTextShadow == nil then cfg.hpTextShadow = true end
    cfg.mpTextBold    = cfg.mpTextBold    or false
    if cfg.mpTextShadow == nil then cfg.mpTextShadow = true end
    cfg.levelBold     = cfg.levelBold     or false
    if cfg.levelShadow == nil then cfg.levelShadow = true end

    -- Border
    if cfg.borderEnabled == nil then cfg.borderEnabled = false end
    cfg.borderSize = cfg.borderSize or 1
    
    -- Rahmenfarbe (für Pixel / generell)
    cfg.borderColor = cfg.borderColor or { r = 0, g = 0, b = 0 }

    if not cfg.borderStyle or cfg.borderStyle == "" then
        cfg.borderStyle = "PIXEL"
    end


    -- Position der Player-Gruppe (Anker für Player1)
    cfg.anchorPoint = cfg.anchorPoint or "CENTER"
    if cfg.anchorX == nil then cfg.anchorX = -250 end
    if cfg.anchorY == nil then cfg.anchorY = 150 end

    -- Layout-Richtung & Abstand zwischen Frames
    if cfg.layoutOrientation ~= "HORIZONTAL" and cfg.layoutOrientation ~= "VERTICAL" then
        cfg.layoutOrientation = "VERTICAL"  -- Standard: untereinander
    end

    if type(cfg.spacing) ~= "number" then
        cfg.spacing = 4
    elseif cfg.spacing < 0 then
        cfg.spacing = 0
    end

    -- Out-of-Range Transparenz (1.0 = normal, 0.6 = etwas ausgegraut)
    cfg.rangeAlpha = cfg.rangeAlpha or 0.6

    -- Buff-/Debuff-Config (muss zu deiner ConfigUI passen)
    cfg.buffs   = cfg.buffs   or {}
    cfg.debuffs = cfg.debuffs or {}

    cfg.buffs.enabled = (cfg.buffs.enabled ~= false)
    cfg.buffs.anchor  = cfg.buffs.anchor or "TOPLEFT"
    cfg.buffs.x       = cfg.buffs.x or 0
    cfg.buffs.y       = cfg.buffs.y or 10
    cfg.buffs.size    = cfg.buffs.size or 24
    cfg.buffs.grow    = cfg.buffs.grow or "RIGHT"
    cfg.buffs.max     = cfg.buffs.max or 12
    cfg.buffs.perRow  = cfg.buffs.perRow or 8
    cfg.buffs.onlyOwn = (cfg.buffs.onlyOwn == true)

    cfg.debuffs.enabled        = (cfg.debuffs.enabled ~= false)
    cfg.debuffs.anchor         = cfg.debuffs.anchor or "TOPLEFT"
    cfg.debuffs.x              = cfg.debuffs.x or 0
    cfg.debuffs.y              = cfg.debuffs.y or -26
    cfg.debuffs.size           = cfg.debuffs.size or 24
    cfg.debuffs.grow           = cfg.debuffs.grow or "RIGHT"
    cfg.debuffs.max            = cfg.debuffs.max or 12
    cfg.debuffs.perRow         = cfg.debuffs.perRow or 8
    cfg.debuffs.onlyDispellable = (cfg.debuffs.onlyDispellable == true)

    -- Role-Icon
    if cfg.roleIconEnabled == nil then
        cfg.roleIconEnabled = true
    end
    cfg.roleIconSize    = cfg.roleIconSize    or 16
    cfg.roleIconAnchor  = cfg.roleIconAnchor  or "BOTTOMLEFT"
    cfg.roleIconXOffset = cfg.roleIconXOffset or 4
    cfg.roleIconYOffset = cfg.roleIconYOffset or 4

    -- Ready-Check-Icon
    if cfg.readyIconEnabled == nil then
        cfg.readyIconEnabled = true
    end
    cfg.readyIconSize    = cfg.readyIconSize    or 20
    cfg.readyIconAnchor  = cfg.readyIconAnchor  or "CENTER"
    cfg.readyIconXOffset = cfg.readyIconXOffset or 0
    cfg.readyIconYOffset = cfg.readyIconYOffset or 0

    -- Absorb / HealAbsorb Defaults (wie beim Player)
    if cfg.absorbEnabled == nil then
        cfg.absorbEnabled = true
    end
    if cfg.healAbsorbEnabled == nil then
        cfg.healAbsorbEnabled = true
    end

    return cfg
end

-- Für Debugging zugreifbar machen
AI.GetPlayerConfig = GetPlayerConfig

-------------------------------------------------
-- Presets-API für das Config-UI
-------------------------------------------------
local function ApplyPresetToConfig(cfg, preset)
    if not preset then return end
    for k, v in pairs(preset) do
        cfg[k] = v
    end
end

function M.GetPresets()
    return Player_PRESETS
end

function M.ApplyPreset(key)
    local preset = Player_PRESETS[key]
    if not preset then return end

    local cfg = GetPlayerConfig()
    ApplyPresetToConfig(cfg, preset)

    if AI and AI.RefreshModule then
        AI.RefreshModule("player")
    else
        if M.ApplyLayout then
            M.ApplyLayout()
        end
        if M.UpdateAll then
            M.UpdateAll()
        end
    end
end

-------------------------------------------------
-- Blizzard-Playerframes verstecken / wiederherstellen
-------------------------------------------------
local function HideBlizzardPlayer()
    if not PlayerFrame then return end

    PlayerFrame:SetAlpha(0)
    PlayerFrame:EnableMouse(false)

    if PlayerFrame.healthbar and PlayerFrame.healthbar.TextString then
        PlayerFrame.healthbar.TextString:Hide()
    end
    if PlayerFrame.manabar and PlayerFrame.manabar.TextString then
        PlayerFrame.manabar.TextString:Hide()
    end
end

local function RestoreBlizzardPlayer()
    if not PlayerFrame then return end

    PlayerFrame:SetAlpha(1)
    PlayerFrame:EnableMouse(true)

    if PlayerFrame.healthbar and PlayerFrame.healthbar.TextString then
        PlayerFrame.healthbar.TextString:Show()
    end
    if PlayerFrame.manabar and PlayerFrame.manabar.TextString then
        PlayerFrame.manabar.TextString:Show()
    end
end

-------------------------------------------------
-- Hilfsfunktionen (Farben / Fonts)
-------------------------------------------------
local function GetClassColor(unit)
    local _, class = UnitClass(unit or "player")
    if class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class] then
        local c = RAID_CLASS_COLORS[class]
        return c.r, c.g, c.b
    end
    return 1, 1, 1
end

local function GetPowerColor(unit)
    local powerType, powerToken

    -- Midnight kann zickig sein: UnitPowerType in pcall kapseln
    if UnitPowerType then
        local ok, pt, token = pcall(UnitPowerType, unit)
        if ok then
            powerType, powerToken = pt, token
        end
    end

    if powerToken and PowerBarColor and PowerBarColor[powerToken] then
        local c = PowerBarColor[powerToken]
        return c.r, c.g, c.b
    end
    if powerType and PowerBarColor and PowerBarColor[powerType] then
        local c = PowerBarColor[powerType]
        return c.r, c.g, c.b
    end
    return 0, 0.4, 1
end

local function GetTextColorFromConfig(cfgColor, useClassColor, unit)
    if useClassColor then
        return GetClassColor(unit)
    end
    if cfgColor then
        return cfgColor.r or 1, cfgColor.g or 1, cfgColor.b or 1
    end
    return 1, 1, 1
end

-- Hilfsfunktion: Font-Pfad anhand des Keys aus der Config bestimmen
local function Player_ResolveFontPath(fontKey)
    local key = fontKey

    if not key or key == "" then
        key = "DEFAULT"
    end

    -- 1) SharedMedia-Font: nutzt den Key 1:1 (z.B. "Expressway", "PT Sans Narrow")
    if LSM and key and key ~= "" then
        local ok, path = pcall(LSM.Fetch, LSM, "font", key, false) -- false = kein stilles Fallback
        if ok and path then
            return path
        end
    end

    -- 3) Fallback: das, was GameFontNormal aktuell nutzt
    local fallback = select(1, GameFontNormal:GetFont())
    return fallback or "Fonts\\FRIZQT__.TTF"
end

local function SetFontStyle(fs, size, bold, shadow)
    if not fs then return end

    size   = size or 12
    bold   = bold and true or false
    shadow = (shadow ~= false)

    local cfg      = GetPlayerConfig()
    local fontKey  = cfg.fontFace
    local fontPath = Player_ResolveFontPath(fontKey)

    -------------------------------------------------
    -- Outline-Stil aus Config + "bold"-Verstärkung
    -------------------------------------------------
    local outlineMode = cfg.fontOutline or "NONE"
    local flags = ""

    if outlineMode == "OUTLINE" then
        flags = "OUTLINE"
    elseif outlineMode == "THICK" then
        flags = "THICKOUTLINE"
    elseif outlineMode == "MONO" then
        flags = "MONOCHROMEOUTLINE"
    end

    if bold then
        if flags == "" then
            flags = "OUTLINE"
        elseif flags == "OUTLINE" then
            flags = "THICKOUTLINE"
        end
    end

    -------------------------------------------------
    -- Font setzen, mit Fallback falls der Pfad nicht geht
    -------------------------------------------------
    local ok = false

    if fontPath and fontPath ~= "" then
        ok = fs:SetFont(fontPath, size, flags)
    end

    if not ok then
        -- Fallback auf GameFontNormal, damit Text NIE unsichtbar bleibt
        local fallback = select(1, GameFontNormal:GetFont())
        fs:SetFont(fallback or "Fonts\\FRIZQT__.TTF", size, flags)

        -- Optional: einmalige Warnung (kannst du auch wieder auskommentieren)
        -- print("Avoid Player: Font konnte nicht geladen werden:", tostring(fontKey), "->", tostring(fontPath))
    end

    -------------------------------------------------
    -- Schatten
    -------------------------------------------------
    if shadow then
        fs:SetShadowOffset(1, -1)
        fs:SetShadowColor(0, 0, 0, 1)
    else
        fs:SetShadowOffset(0, 0)
        fs:SetShadowColor(0, 0, 0, 0)
    end
end

-------------------------------------------------
-- HP / Mana Textformatierung
-------------------------------------------------
local function FormatHPText(unit, mode)
    if not UnitExists(unit) then
        return ""
    end

    local hp    = UnitHealth(unit)
    local maxHP = UnitHealthMax(unit)

    if AbbreviateLargeNumbers then
        hpStr  = AbbreviateLargeNumbers(hp)
        maxStr = AbbreviateLargeNumbers(maxHP)
    end

    if not maxHP or maxHP <= 0 then
        return ""
    end

    -- Midnight: Prozentwert direkt holen (wie bei UnitPowerPercent)
    local pct = UnitHealthPercent and UnitHealthPercent(unit, false, true) or nil

    if mode == "PERCENT" then
        if pct ~= nil then
            return string.format("%d%%", pct)
        end
        return ""
    elseif mode == "BOTH" then
        return string.format("%s / %s", hp, maxHP)
    elseif mode == "BOTHSHORT" then
        return string.format("%s / %s", hpStr, maxStr)
    elseif mode == "CURSHORT" then
        return string.format("%s", hpStr)
    elseif mode == "CUR" then
        return hp
    end
end

local function FormatPowerText(unit, mode, pType, p, pMax)
    if not p or not pMax or pMax <= 0 then
        return ""
    end

    if mode ~= "PERCENT" and mode ~= "BOTH" and mode ~= "BOTHSHORT"  and mode ~= "CUR"  and mode ~= "CURSHORT" then
        mode = "BOTHSHORT"
    end

    local pStr   = tostring(p)
    local maxStr = tostring(pMax)
    if AbbreviateLargeNumbers then
        pStr   = AbbreviateLargeNumbers(p)
        maxStr = AbbreviateLargeNumbers(pMax)
    end

    if mode == "PERCENT" then
        local pct = UnitPowerPercent and UnitPowerPercent(unit, pType, false, true)
        if pct ~= nil then
            return string.format("%d%%", pct)
        else
            return pStr
        end   
    elseif mode == "BOTH" then
        return string.format("%s / %s", pStr, maxStr)
    elseif mode == "CUR" then
        return string.format("%s", pStr)
    end
end

-------------------------------------------------
-- Frames / globale Variablen
-------------------------------------------------
local frames = {}
local eventFrame
local movingMode = false
local rangeFrame      -- kleines OnUpdate-Frame für Range-Checks
local auraUpdateFrame

-- NEU: globaler Zustand, ob gerade ein Readycheck läuft
local readyCheckActive = false

local function ForEachPlayerFrame(func)
    for _, unit in ipairs(Player_UNITS) do
        local f = frames[unit]
        if f then
            func(f, unit)
        end
    end
end

local function SetBarTexture(bar, texKey)
    if not bar then return end
    texKey = texKey or "DEFAULT"

    local tex

    -- Zuerst schauen: ist das einer unserer festen Keys?
    if BAR_TEXTURES[texKey] then
        tex = BAR_TEXTURES[texKey]
    elseif LSM and texKey ~= "" then
        -- ansonsten als LSM-Statusbar versuchen
        local ok, lsmTex = pcall(LSM.Fetch, LSM, "statusbar", texKey)
        if ok and lsmTex then
            tex = lsmTex
        end
    end

    -- Fallback
    tex = tex or BAR_TEXTURES.DEFAULT
    bar:SetStatusBarTexture(tex)
end

-------------------------------------------------
-- Out-of-Range Visuals
-------------------------------------------------
local function UpdateRangeVisual(frame)
    if not frame or not frame.unit then return end

    local cfg  = GetPlayerConfig()
    local unit = frame.unit

    -- Basisalpha aus Config
    local baseAlpha = cfg.alpha or 1
    local fadeAlpha = (cfg.rangeAlpha or 0.6)

    -- 1) Unit existiert überhaupt nicht mehr → Frame komplett ausblenden
    if type(unit) ~= "string" or not UnitExists(unit) then
        frame:SetAlpha(0)
        frame:EnableMouse(false)
        return
    end

    -- 2) Unit existiert, ist aber offline → leicht ausgegraut
    if not UnitIsConnected(unit) then
        frame:SetAlpha(baseAlpha * fadeAlpha)
        return
    end

    -- 3) Lebende, verbundene Player-Mitglieder → normale Alpha
    frame:SetAlpha(baseAlpha)
end

local function UpdateAllRanges()
    ForEachPlayerFrame(function(f)
        if f:IsShown() then
            UpdateRangeVisual(f)
        end
    end)
end

local function ApplyTextLayout(frame, fs, show, size, anchor, xOff, yOff, bold, shadow, cfgColor, useClassColor)
    if not frame or not fs then return end

    if not show then
        fs:Hide()
        return
    end

    SetFontStyle(fs, size, bold, shadow)

    local r, g, b = GetTextColorFromConfig(cfgColor, useClassColor, frame.unit)
    fs:SetTextColor(r, g, b, 1)

    fs:ClearAllPoints()
    anchor = anchor or "CENTER"
    xOff   = xOff or 0
    yOff   = yOff or 0

    local anchorFrame = frame.textLayer or frame
    fs:SetPoint(anchor, anchorFrame, anchor, xOff, yOff)

    fs:SetDrawLayer("OVERLAY", 5)
    fs:Show()
end

-------------------------------------------------
-- Border
-------------------------------------------------
local function ApplyBorderLayout(frame, cfg)
    if not frame then return end

    if not cfg.borderEnabled then
        if frame.border then
            frame.border:Hide()
        end
        return
    end

    if not frame.border then
        frame.border = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    end

        local style    = cfg.borderStyle or "PIXEL"
    local size     = cfg.borderSize or 1
    local edgeFile
    local edgeSize
    local insetLeft, insetRight, insetTop, insetBottom = 0, 0, 0, 0

    -- PIXEL-Varianten bleiben interne 1px-Rahmen
    if style == "PIXEL" then
        edgeFile = "Interface\\Buttons\\WHITE8x8"
        edgeSize = size
        insetLeft, insetRight, insetTop, insetBottom = -size, -size, -size, -size
    elseif style == "THIN" then
        edgeFile = "Interface\\Buttons\\WHITE8x8"
        edgeSize = 1
        insetLeft, insetRight, insetTop, insetBottom = -1, -1, -1, -1
    elseif style == "THICK" then
        edgeFile = "Interface\\Buttons\\WHITE8x8"
        edgeSize = 2
        insetLeft, insetRight, insetTop, insetBottom = -2, -2, -2, -2

    -- Klassische Blizzard-Rahmen
    elseif style == "TOOLTIP" then
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border"
        edgeSize = 16
        insetLeft, insetRight, insetTop, insetBottom = 3, 3, 3, 3
    elseif style == "DIALOG" then
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border"
        edgeSize = 16
        insetLeft, insetRight, insetTop, insetBottom = 3, 3, 3, 3

    -- Alles andere interpretieren wir als LibSharedMedia-Border
    elseif LSM and style and style ~= "" then
        local ok, borderTex = pcall(LSM.Fetch, LSM, "border", style, false)
        if ok and borderTex then
            edgeFile = borderTex
            edgeSize = 16
            insetLeft, insetRight, insetTop, insetBottom = 3, 3, 3, 3
        else
            edgeFile = "Interface\\Buttons\\WHITE8x8"
            edgeSize = size
            insetLeft, insetRight, insetTop, insetBottom = -size, -size, -size, -size
        end

    -- Fallback: einfacher Pixel-Rahmen
    else
        edgeFile = "Interface\\Buttons\\WHITE8x8"
        edgeSize = size
        insetLeft, insetRight, insetTop, insetBottom = -size, -size, -size, -size
    end

    frame.border:SetBackdrop({
        edgeFile = edgeFile,
        edgeSize = edgeSize,
        insets   = {
            left   = insetLeft,
            right  = insetRight,
            top    = insetTop,
            bottom = insetBottom,
        },
    })

    -- Nur PIXEL / THIN / THICK einfärben (Colorcircle / cfg.borderColor)
    if style == "PIXEL" or style == "THIN" or style == "THICK" then
        local r, g, b, a = 0, 0, 0, 1
        if cfg.borderColor then
            r = cfg.borderColor.r or r
            g = cfg.borderColor.g or g
            b = cfg.borderColor.b or b
        end
        frame.border:SetBackdropBorderColor(r, g, b, a)
    end
    -- TOOLTIP / DIALOG: KEIN SetBackdropBorderColor → Blizzard-Färbung bleibt

    -- Innenfläche bleibt transparent
    frame.border:SetBackdropColor(0, 0, 0, 0.4)

    frame.border:ClearAllPoints()
    frame.border:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
    frame.border:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 0, 0)

    local baseLevel = frame:GetFrameLevel() or 1
    frame.border:SetFrameLevel(baseLevel + 2)
    frame.border:Show()
end

-------------------------------------------------
-- Icons aktualisieren (Combat / Resting / Leader / Raidtarget)
-------------------------------------------------
local function UpdateIcons(frame)
    if not frame or not frame.unit then return end

    local unit = frame.unit
    if not UnitExists(unit) then
        if frame.combatIcon then frame.combatIcon:Hide() end
        if frame.restingIcon then frame.restingIcon:Hide() end
        if frame.leaderIcon then frame.leaderIcon:Hide() end
        if frame.raidIcon   then frame.raidIcon:Hide()   end
        return
    end

    local cfg = GetPlayerConfig()
    local anchorFrame = frame.iconLayer or frame

    -- Combat-Icon
    if frame.combatIcon then
        local enabled = (cfg.combatIconEnabled ~= false)
        if enabled and UnitAffectingCombat(unit) then
            local size   = cfg.combatIconSize   or 24
            local anchor = cfg.combatIconAnchor or "TOPLEFT"
            local xOff   = cfg.combatIconXOffset or -4
            local yOff   = cfg.combatIconYOffset or 4

            frame.combatIcon:ClearAllPoints()
            frame.combatIcon:SetSize(size, size)
            frame.combatIcon:SetPoint(anchor, anchorFrame, anchor, xOff, yOff)
            frame.combatIcon:Show()
        else
            frame.combatIcon:Hide()
        end
    end

    -- Resting-Icon:
    -- Im Playerframe nie anzeigen (Resting ist eigentlich nur für den eigenen Player sinnvoll
    -- und der hat sein eigenes Modul). Wichtig: kein UnitIsUnit() wegen Midnight secret values.
    if frame.restingIcon then
        frame.restingIcon:Hide()
    end

    -- Leader-Icon
    if frame.leaderIcon then
        local enabled = (cfg.leaderIconEnabled ~= false)
        if enabled and UnitIsGroupLeader(unit) then
            local size   = cfg.leaderIconSize   or 18
            local anchor = cfg.leaderIconAnchor or "TOPRIGHT"
            local xOff   = cfg.leaderIconXOffset or 4
            local yOff   = cfg.leaderIconYOffset or 4

            frame.leaderIcon:ClearAllPoints()
            frame.leaderIcon:SetSize(size, size)
            frame.leaderIcon:SetPoint(anchor, anchorFrame, anchor, xOff, yOff)
            frame.leaderIcon:Show()
        else
            frame.leaderIcon:Hide()
        end
    end

    -- Raidtarget-Icon
    if frame.raidIcon then
        local enabled = (cfg.raidIconEnabled ~= false)
        local index   = GetRaidTargetIndex(unit)

        if enabled and index then
            local size   = cfg.raidIconSize   or 20
            local anchor = cfg.raidIconAnchor or "TOP"
            local xOff   = cfg.raidIconXOffset or 0
            local yOff   = cfg.raidIconYOffset or 10

            frame.raidIcon:ClearAllPoints()
            frame.raidIcon:SetSize(size, size)
            frame.raidIcon:SetPoint(anchor, frame, anchor, xOff, yOff)

            -- nur aufrufen, wenn die Textur wirklich existiert
            if frame.raidIcon.SetTexCoord then
                SetRaidTargetIconTexture(frame.raidIcon, index)
            end

            frame.raidIcon:Show()
        else
            frame.raidIcon:Hide()
        end
    end
    
    -- Role-Icon (Tank / Healer / Damager)
    if frame.roleIcon then
        local enabled = (cfg.roleIconEnabled ~= false)

        if enabled and UnitGroupRolesAssigned then
            local role = UnitGroupRolesAssigned(unit)

            if role == "TANK" or role == "HEALER" or role == "DAMAGER" then
                local size   = cfg.roleIconSize    or 16
                local anchor = cfg.roleIconAnchor  or "BOTTOMLEFT"
                local xOff   = cfg.roleIconXOffset or 4
                local yOff   = cfg.roleIconYOffset or 4

                frame.roleIcon:ClearAllPoints()
                frame.roleIcon:SetSize(size, size)
                frame.roleIcon:SetPoint(anchor, anchorFrame, anchor, xOff, yOff)
                frame.roleIcon:SetTexture("Interface\\LFGFrame\\UI-LFG-ICON-PORTRAITROLES")

                -- TexCoords je nach Rolle setzen
                if role == "TANK" then
                    -- Tank-Symbol
                    frame.roleIcon:SetTexCoord(0, 19/64, 22/64, 41/64)
                elseif role == "HEALER" then
                    -- Heiler-Symbol
                    frame.roleIcon:SetTexCoord(20/64, 39/64, 1/64, 20/64)
                elseif role == "DAMAGER" then
                    -- DPS-Symbol
                    frame.roleIcon:SetTexCoord(20/64, 39/64, 22/64, 41/64)
                end

                frame.roleIcon:Show()
            else
                frame.roleIcon:Hide()
            end
        else
            frame.roleIcon:Hide()
        end
    end

        -- Ready-Check-Icon
    if frame.readyIcon then
        local enabled = (cfg.readyIconEnabled ~= false)

        if enabled and readyCheckActive and GetReadyCheckStatus then
            local status = GetReadyCheckStatus(unit)

            local tex
            if status == "ready" then
                tex = "Interface\\RAIDFRAME\\ReadyCheck-Ready"
            elseif status == "notready" then
                tex = "Interface\\RAIDFRAME\\ReadyCheck-NotReady"
            elseif status == "waiting" or status == nil then
                tex = "Interface\\RAIDFRAME\\ReadyCheck-Waiting"
            else
                -- Irgendein anderer Status → Icon verstecken
                frame.readyIcon:Hide()
                return
            end

            local size   = cfg.readyIconSize    or 20
            local anchor = cfg.readyIconAnchor  or "CENTER"
            local xOff   = cfg.readyIconXOffset or 0
            local yOff   = cfg.readyIconYOffset or 0

            frame.readyIcon:ClearAllPoints()
            frame.readyIcon:SetSize(size, size)
            frame.readyIcon:SetPoint(anchor, anchorFrame, anchor, xOff, yOff)
            frame.readyIcon:SetTexture(tex)
            frame.readyIcon:Show()
        else
            -- Kein aktiver Readycheck oder Option aus → Icon weg
            frame.readyIcon:Hide()
        end
    end
end

-------------------------------------------------
-- Buffs / Debuffs
-------------------------------------------------
local AURA_SPACING = 2

local function EnsureAuraButtons(frame, kind, maxCount)
    local key = (kind == "DEBUFF") and "debuffButtons" or "buffButtons"
    frame[key] = frame[key] or {}
    local list = frame[key]

    local baseLevel = (frame.textLayer and frame.textLayer:GetFrameLevel() or frame:GetFrameLevel()) + 1

    for i = #list + 1, maxCount do
        local btn = CreateFrame("Button", nil, frame)
        btn.icon = btn:CreateTexture(nil, "ARTWORK")
        btn.icon:SetAllPoints()

        btn:SetFrameLevel(baseLevel)
        btn:Hide()

        list[i] = btn
    end

    return list
end

local function LayoutAuraButtons(frame, buttons, cfg)
    if not buttons or not cfg then return end

    local anchorPoint = cfg.anchor or "TOPLEFT"
    local grow        = cfg.grow or "RIGHT"
    local size        = cfg.size or 24
    local perRow      = cfg.perRow or 8
    local xBase       = cfg.x or 0
    local yBase       = cfg.y or 0

    local anchorFrame = frame

    local col, row = 0, 0

    for _, btn in ipairs(buttons) do
        if btn:IsShown() then
            btn:SetSize(size, size)
            btn:ClearAllPoints()

            local x = xBase
            local y = yBase

            if grow == "RIGHT" then
                x = x + col * (size + AURA_SPACING)
                y = y - row * (size + AURA_SPACING)
            elseif grow == "LEFT" then
                x = x - col * (size + AURA_SPACING)
                y = y - row * (size + AURA_SPACING)
            elseif grow == "UP" then
                x = x + col * (size + AURA_SPACING)
                y = y + row * (size + AURA_SPACING)
            elseif grow == "DOWN" then
                x = x + col * (size + AURA_SPACING)
                y = y - row * (size + AURA_SPACING)
            else
                x = x + col * (size + AURA_SPACING)
                y = y - row * (size + AURA_SPACING)
            end

            btn:SetPoint(anchorPoint, anchorFrame, anchorPoint, x, y)

            col = col + 1
            if col >= perRow then
                col = 0
                row = row + 1
            end
        end
    end
end

local function UpdateAuras(frame)
    if not frame or not frame.unit or not UnitExists(frame.unit) then
        if frame.buffButtons then
            for _, b in ipairs(frame.buffButtons) do b:Hide() end
        end
        if frame.debuffButtons then
            for _, b in ipairs(frame.debuffButtons) do b:Hide() end
        end
        return
    end

    local cfg      = GetPlayerConfig()
    local buffsCfg = cfg.buffs or {}
    local debuffsCfg = cfg.debuffs or {}
    local unit     = frame.unit

    -------------------------------------------------
    -- BUFFS
    -------------------------------------------------
    if buffsCfg.enabled and AuraUtil and AuraUtil.ForEachAura then
        local maxBuffs = buffsCfg.max or 12
        local buttons  = EnsureAuraButtons(frame, "BUFF", maxBuffs)

        -- alles ausblenden
        for _, b in ipairs(buttons) do b:Hide() end

        local count = 0

        AuraUtil.ForEachAura(unit, "HELPFUL", nil, function(aura)
        if not aura or not aura.icon then
            return false
        end

        -- WICHTIG:
        -- KEIN Filter mehr nach "onlyOwn"
        -- KEIN aura.sourceUnit
        -- KEIN aura.isFromPlayerOrPlayerPet
        -- KEIN UnitIsUnit(...) -> alles Secret-Value-gefährlich

        count = count + 1
        if count > maxBuffs then
            return true  -- stoppt die Schleife
        end

        local btn = buttons[count]
        btn.icon:SetTexture(aura.icon)
        btn:Show()

        return false
    end, true)

        LayoutAuraButtons(frame, buttons, buffsCfg)
    else
        if frame.buffButtons then
            for _, b in ipairs(frame.buffButtons) do b:Hide() end
        end
    end


    -------------------------------------------------
    -- DEBUFFS
    -------------------------------------------------
    if debuffsCfg.enabled and AuraUtil and AuraUtil.ForEachAura then
        local maxDebuffs = debuffsCfg.max or 12
        local buttons    = EnsureAuraButtons(frame, "DEBUFF", maxDebuffs)

        for _, b in ipairs(buttons) do b:Hide() end

        local count = 0

        AuraUtil.ForEachAura(unit, "HARMFUL", nil, function(aura)
            if not aura or not aura.icon then
                return false
            end

            if debuffsCfg.onlyDispellable then
                -- Packed Aura: isDispellable / dispelName sind sicher
                if not aura.isDispellable and not aura.dispelName then
                    return false
                end
            end

            count = count + 1
            if count > maxDebuffs then
                return true
            end

            local btn = buttons[count]
            btn.icon:SetTexture(aura.icon)
            btn:Show()

            return false
        end, true)

        LayoutAuraButtons(frame, buttons, debuffsCfg)
    else
        if frame.debuffButtons then
            for _, b in ipairs(frame.debuffButtons) do b:Hide() end
        end
    end
end

-- Schneidet lange Namen auf eine maximale Pixelbreite und hängt "..." an
local function SetTruncatedName(frame, fullName, maxWidth)
    if not frame or not frame.nameText or not fullName then return end
    if maxWidth <= 0 then
        frame.nameText:SetText("")
        return
    end

    local fs = frame.nameText

    -- Erst mal im vollen Text messen
    fs:SetWidth(0)         -- keine künstliche Begrenzung
    fs:SetText(fullName)
    local fullWidth = fs:GetStringWidth() or 0

    -- Passt eh → nichts tun
    if fullWidth <= maxWidth then
        return
    end

    local ellipsis = "..."
    fs:SetText(ellipsis)
    local ellipsisWidth = fs:GetStringWidth() or 0
    if ellipsisWidth > maxWidth then
        -- So schmal, dass nicht mal "..." reinpasst
        fs:SetText("")
        return
    end

    -- Binäre Suche nach der maximalen Länge, die inkl. "..." noch reinpasst
    local nameLen = #fullName
    local left, right = 1, nameLen
    local best = ellipsis

    while left <= right do
        local mid = math.floor((left + right) / 2)
        local candidate = string.sub(fullName, 1, mid) .. ellipsis

        fs:SetText(candidate)
        local w = fs:GetStringWidth() or 0

        if w <= maxWidth then
            best = candidate
            left = mid + 1
        else
            right = mid - 1
        end
    end

    fs:SetText(best)
    -- Optional: tatsächliche Breite begrenzen, damit nichts drüberzeichnet
    fs:SetWidth(maxWidth)
end

-- Berechnet max. Breite für den Namen relativ zu Frame-Breite, Offsets, Fontgröße
local function UpdateNameText(frame, cfg)
    if not frame or not frame.nameText then return end

    local unit = frame.unit
    if not unit or not UnitExists(unit) then
        frame.nameText:SetText("")
        return
    end

    local name = UnitName(unit) or ""
    if name == "" then
        frame.nameText:SetText("")
        return
    end

    -- Framebreite nehmen und ein wenig Padding abziehen
    local frameWidth = frame:GetWidth() or 0

    -- Links: etwas Luft + dein X-Offset, rechts: etwas Luft
    local padLeft  = 6 + math.abs(cfg.nameXOffset or 0)
    local padRight = 6

    local maxWidth = frameWidth - padLeft - padRight
    if maxWidth < 0 then maxWidth = 0 end

    SetTruncatedName(frame, name, maxWidth)
end

-------------------------------------------------
-- Frame-Layout
-------------------------------------------------
local function ApplyFrameLayout(frame, cfg)
    if not frame then return end

    local unit = frame.unit
    -- Sicherheit: nur weitermachen, wenn wir ein gültiges Unit-Token haben
    if type(unit) ~= "string" then
        return
    end

    -- Wenn die Unit nicht (mehr) existiert, Frame unsichtbar lassen
    -- und KEIN Layout anwenden, sonst kommen die leeren Hintergründe zurück.
    if not UnitExists or not UnitExists(unit) then
        frame:SetAlpha(0)
        frame:EnableMouse(false)
        return
    end

    -- Sicherstellen, dass iconLayer existiert (falls alte Frames ohne Layer rumfliegen)
    if not frame.iconLayer then
        frame.iconLayer = CreateFrame("Frame", nil, frame)
        frame.iconLayer:SetAllPoints(frame)
    end
    local width  = cfg.width or 220
    local height = cfg.height or 60


    -------------------------------------------------
    -- Innenbereich bestimmen (wegen Rahmen)
    -------------------------------------------------
    local innerInset = 1

    if cfg.borderEnabled then
        if cfg.borderStyle == "PIXEL" or cfg.borderStyle == "THIN" or cfg.borderStyle == "THICK" then
            
            -- Pixel-Rahmen (PIXEL / THIN / THICK) -> Inset = Border-Dicke
            innerInset = cfg.borderSize or 1
            if innerInset < 1 then
                innerInset = 1
            end
        else
            -- Blizzard Tooltip/Dialog sind optisch breiter, fester Wert
            innerInset = 4
        end
    end

    -- Inhaltshöhe = Framehöhe minus Rahmen oben/unten
    local contentHeight = height - innerInset * 2
    if contentHeight < 1 then
        contentHeight = 1
    end

    -------------------------------------------------
    -- HP / MP Höhen wie im Playerframe, aber im Inhalt
    -------------------------------------------------
    local ratio = tonumber(cfg.hpRatio) or 0.66
    if ratio < 0.1 then ratio = 0.1 end
    if ratio > 0.9 then ratio = 0.9 end

    local hpHeight, mpHeight
    if cfg.manaEnabled then
        hpHeight = math.floor(contentHeight * ratio + 0.5)
        mpHeight = contentHeight - hpHeight

        -- Sicherheitsnetz, damit beide Bars immer > 0 bleiben
        if hpHeight < 1 then hpHeight = 1 end
        if mpHeight < 1 then
            mpHeight = 1
            hpHeight = contentHeight - mpHeight
            if hpHeight < 1 then hpHeight = 1 end
        end
    else
        -- Keine Manabar: HP füllt den kompletten Inhalt
        hpHeight = contentHeight
        mpHeight = 0
    end

    frame:SetSize(width, height)
    frame:SetAlpha(cfg.alpha or 1)

    -------------------------------------------------
    -- Power – Midnight/secret values absichern
    -------------------------------------------------
    local pType = 0
    if UnitPowerType then
        local ok, pt = pcall(UnitPowerType, unit)
        if ok and type(pt) == "number" then
            pType = pt
        end
    end

    local power, powerMax = 0, 0
    if UnitPower and UnitPowerMax then
        local ok1, v1 = pcall(UnitPower, unit, pType)
        if ok1 and type(v1) == "number" then
            power = v1
        end

        local ok2, v2 = pcall(UnitPowerMax, unit, pType)
        if ok2 and type(v2) == "number" then
            powerMax = v2
        end
    end

    -------------------------------------------------
    -- Position des Frames – Player: immer nur 1 Frame
    -------------------------------------------------
    frame:ClearAllPoints()
    frame:SetPoint(
        cfg.anchorPoint or "CENTER",
        UIParent,
        cfg.anchorPoint or "CENTER",
        (cfg.anchorX or 0),
        (cfg.anchorY or 0)
    )

    -------------------------------------------------
    -- Hintergrund im Innenbereich
    -------------------------------------------------
    if not frame.bg then
        frame.bg = frame:CreateTexture(nil, "BACKGROUND")
    end

    frame.bg:ClearAllPoints()
    frame.bg:SetPoint("TOPLEFT", frame, "TOPLEFT", innerInset, -innerInset)
    frame.bg:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -innerInset, innerInset)

    local bgR, bgG, bgB, bgA = 0, 0, 0, 0.6
    if cfg.frameBgMode == "CLASS" then
        bgR, bgG, bgB = GetClassColor(unit)
        bgA = 0.35
    elseif cfg.frameBgMode == "CLASSPOWER" then
        local r1, g1, b1 = GetClassColor(unit)
        local r2, g2, b2 = GetPowerColor(unit)
        bgR = (r1 + r2) / 2
        bgG = (g1 + g2) / 2
        bgB = (b1 + b2) / 2
        bgA = 0.45
    end
    frame.bg:SetColorTexture(bgR, bgG, bgB, bgA)

    -------------------------------------------------
    -- FrameLevel / Layering
    -------------------------------------------------
    local baseLevel = frame:GetFrameLevel() or 1
    frame.healthBar:SetFrameLevel(baseLevel + 1)
    frame.powerBar:SetFrameLevel(baseLevel + 1)
    if frame.border then
        frame.border:SetFrameLevel(baseLevel + 2)
    end
    if frame.textLayer then
        frame.textLayer:SetFrameLevel(baseLevel + 3)
    end
    if frame.iconLayer then
        frame.iconLayer:SetFrameLevel(baseLevel + 4)
    end

    -------------------------------------------------
    -- HealthBar + PowerBar Layout im Innenbereich
    -------------------------------------------------
    frame.healthBar:ClearAllPoints()

    if cfg.manaEnabled and mpHeight > 0 then
        -- HP oben, fester Anteil, aber innerhalb des Rahmens
        frame.healthBar:SetPoint("TOPLEFT",  frame, "TOPLEFT",  innerInset, -innerInset)
        frame.healthBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -innerInset, -innerInset)
        frame.healthBar:SetHeight(hpHeight)
    else
        -- Keine Mana-Bar: HP füllt den kompletten Innenbereich
        frame.healthBar:SetPoint("TOPLEFT",     frame, "TOPLEFT",     innerInset, -innerInset)
        frame.healthBar:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -innerInset, innerInset)
    end

    SetBarTexture(frame.healthBar, cfg.hpTexture)

    -------------------------------------------------
    -- Absorb / HealAbsorb-Bar wie im Player:
    -- immer deckungsgleich mit der HP-Bar,
    -- ReverseFill von rechts nach links.
    -------------------------------------------------
    if frame.absorbBar then
        frame.absorbBar:ClearAllPoints()
        frame.absorbBar:SetAllPoints(frame.healthBar)
        frame.absorbBar:SetFrameLevel(frame.healthBar:GetFrameLevel() + 1)
        -- ReverseFill wurde bei der Erstellung gesetzt, nicht anfassen
    end

    if frame.healAbsorbBar then
        frame.healAbsorbBar:ClearAllPoints()
        frame.healAbsorbBar:SetAllPoints(frame.healthBar)
        frame.healAbsorbBar:SetFrameLevel(frame.healthBar:GetFrameLevel() + 2)
        -- ReverseFill ebenfalls nur bei Erstellung gesetzt
    end

    -- Farben für Absorb / HealAbsorb aus der Config
    local absorbColor = cfg.absorbColor or { r = 1, g = 1, b = 1, a = 0.35 }
    if frame.absorbBar then
        -- Textur für Absorb-Bar (weiß, wird per Farbe getönt)
        frame.absorbBar:SetStatusBarTexture(BAR_TEXTURES.ABSORB or "Interface\\Buttons\\WHITE8x8")
        frame.absorbBar:SetStatusBarColor(
            absorbColor.r or 1,
            absorbColor.g or 1,
            absorbColor.b or 1,
            absorbColor.a or 0.35
        )
    end

    local healAbsorbColor = cfg.healAbsorbColor or { r = 1, g = 0.8, b = 0, a = 0.8 }
    if frame.healAbsorbBar then
        -- Shield-Overlay bleibt, nur Farbe aus Config
        frame.healAbsorbBar:SetStatusBarColor(
            healAbsorbColor.r or 1,
            healAbsorbColor.g or 0.8,
            healAbsorbColor.b or 0,
            healAbsorbColor.a or 0.8
        )
    end
    -- HP-Farbe wie gehabt
    local hr, hg, hb
    if cfg.hpUseCustomColor then
        hr = cfg.hpCustomColor.r or 0
        hg = cfg.hpCustomColor.g or 1
        hb = cfg.hpCustomColor.b or 0
    elseif cfg.hpColorMode == "CLASS" then
        hr, hg, hb = GetClassColor(unit)
    else
        hr, hg, hb = 0, 1, 0
    end
    frame.healthBar:SetStatusBarColor(hr, hg, hb, 1)

    if not frame.healthBar.bg then
        frame.healthBar.bg = frame.healthBar:CreateTexture(nil, "BACKGROUND")
    end
    frame.healthBar.bg:ClearAllPoints()
    frame.healthBar.bg:SetAllPoints(frame.healthBar)

    -- NEU: Hintergrundfarbe = verlorene HP
    local lc = cfg.hpLossColor or { r = 0, g = 0, b = 0, a = 0.6 }
    frame.healthBar.bg:SetColorTexture(lc.r or 0, lc.g or 0, lc.b or 0, lc.a or 0.6)

    -- PowerBar direkt unter der HP-Bar, auch im Innenbereich
    if cfg.manaEnabled and mpHeight > 0 then
        frame.powerBar:Show()
        frame.powerBar:ClearAllPoints()
        frame.powerBar:SetPoint("TOPLEFT",  frame.healthBar, "BOTTOMLEFT",  0, 0)
        frame.powerBar:SetPoint("TOPRIGHT", frame.healthBar, "BOTTOMRIGHT", 0, 0)
        frame.powerBar:SetHeight(mpHeight)

        SetBarTexture(frame.powerBar, cfg.mpTexture)

        local pr, pg, pb
        if cfg.mpUseCustomColor then
            pr = cfg.mpCustomColor.r or 0
            pg = cfg.mpCustomColor.g or 0
            pb = cfg.mpCustomColor.b or 1
        else
            pr, pg, pb = GetPowerColor(unit)
        end
        frame.powerBar:SetStatusBarColor(pr, pg, pb, 1)

        if not frame.powerBar.bg then
            frame.powerBar.bg = frame.powerBar:CreateTexture(nil, "BACKGROUND")
        end
        frame.powerBar.bg:ClearAllPoints()
        frame.powerBar.bg:SetAllPoints(frame.powerBar)
        frame.powerBar.bg:SetColorTexture(0, 0, 0, 0.6)
    else
        frame.powerBar:Hide()
        if frame.powerBar.bg then
            frame.powerBar.bg:Hide()
        end
    end

    -------------------------------------------------
    -- Border oben drauf
    -------------------------------------------------
    ApplyBorderLayout(frame, cfg)

    -------------------------------------------------
    -- Texte wie gehabt
    -------------------------------------------------
    local name = UnitName(unit) or ""
    frame.nameText:SetText(name)

    local lvl = UnitLevel(unit) or 0
    local levelText = ""
    if lvl > 0 then
        levelText = tostring(lvl)
    end
    frame.levelText:SetText(levelText)

    frame.hpText:SetText(FormatHPText(unit, cfg.hpTextMode))
    frame.mpText:SetText(cfg.manaEnabled and FormatPowerText(unit, cfg.mpTextMode or "BOTH", pType, power or 0, powerMax) or "")

    ApplyTextLayout(
        frame,
        frame.nameText,
        cfg.showName,
        cfg.nameSize,
        cfg.nameAnchor,
        cfg.nameXOffset,
        cfg.nameYOffset,
        cfg.nameBold,
        cfg.nameShadow,
        cfg.nameTextColor,
        cfg.nameTextUseClassColor
    )
    -- Ganz am Ende von ApplyFrameLayout (oder direkt nach dem ApplyTextLayout-Block):
    UpdateNameText(frame, cfg)

    ApplyTextLayout(
        frame,
        frame.hpText,
        cfg.showHPText,
        cfg.hpTextSize,
        cfg.hpTextAnchor,
        cfg.hpTextXOffset,
        cfg.hpTextYOffset,
        cfg.hpTextBold,
        cfg.hpTextShadow,
        cfg.hpTextColor,
        cfg.hpTextUseClassColor
    )

    ApplyTextLayout(
        frame,
        frame.mpText,
        cfg.manaEnabled and cfg.showMPText,
        cfg.mpTextSize,
        cfg.mpTextAnchor,
        cfg.mpTextXOffset,
        cfg.mpTextYOffset,
        cfg.mpTextBold,
        cfg.mpTextShadow,
        cfg.mpTextColor,
        cfg.mpTextUseClassColor
    )

    ApplyTextLayout(
        frame,
        frame.levelText,
        cfg.showLevelText,
        cfg.levelTextSize,
        cfg.levelAnchor,
        cfg.levelXOffset,
        cfg.levelYOffset,
        cfg.levelBold,
        cfg.levelShadow,
        cfg.levelTextColor,
        cfg.levelTextUseClassColor
    )
end

-------------------------------------------------
-- Position speichern
-------------------------------------------------

local function StoreCurrentPosition(frame)
    if not frame or frame.unit ~= "Player1" then return end
    local cfg = GetPlayerConfig()

    local point, _, _, xOfs, yOfs = frame:GetPoint(1)
    cfg.anchorPoint = point or "CENTER"
    cfg.anchorX     = xOfs or 0
    cfg.anchorY     = yOfs or 0
end

-------------------------------------------------
-- Absorb / HealAbsorb Bars aktualisieren (Midnight-safe, wie Player)
-------------------------------------------------
local function UpdateAbsorbBars(frame, hpMax)
    if not frame or not frame.healthBar or not frame.unit then
        return
    end

    local cfg  = GetPlayerConfig()
    local unit = frame.unit

    -- gleiches Max wie die HP-Bar verwenden
    local maxValue = hpMax
    if not maxValue and UnitHealthMax then
        local ok, v = pcall(UnitHealthMax, unit)
        if ok then
            maxValue = v
        end
    end
    if not maxValue then
        maxValue = 1 -- Fallback, kein Vergleich / keine Division nötig
    end

    -------------------------------------------------
    -- Total Absorb (Shields)
    -------------------------------------------------
    if frame.absorbBar then
        if cfg.absorbEnabled then
            frame.absorbBar:SetMinMaxValues(0, maxValue)

            local absorb = UnitGetTotalAbsorbs and UnitGetTotalAbsorbs(unit)
            if not absorb then
                absorb = 0 -- nil → 0, keine Secret-Mathe
            end

            frame.absorbBar:SetValue(absorb)
            frame.absorbBar:Show()
        else
            frame.absorbBar:SetMinMaxValues(0, 1)
            frame.absorbBar:SetValue(0)
            frame.absorbBar:Hide()
        end
    end

    -------------------------------------------------
    -- HealAbsorb (verhindert Heilung)
    -------------------------------------------------
    if frame.healAbsorbBar then
        if cfg.healAbsorbEnabled then
            frame.healAbsorbBar:SetMinMaxValues(0, maxValue)

            local healAbsorb = UnitGetTotalHealAbsorbs and UnitGetTotalHealAbsorbs(unit)
            if not healAbsorb then
                healAbsorb = 0
            end

            frame.healAbsorbBar:SetValue(healAbsorb)
            frame.healAbsorbBar:Show()
        else
            frame.healAbsorbBar:SetMinMaxValues(0, 1)
            frame.healAbsorbBar:SetValue(0)
            frame.healAbsorbBar:Hide()
        end
    end
end

-------------------------------------------------
-- HP / Power aktualisieren – Midnight-safe
-------------------------------------------------
local function UpdateHealthAndPower(frame)
    if not frame or not frame.unit or not UnitExists(frame.unit) then
        return
    end


    local unit = frame.unit
    local cfg  = GetPlayerConfig()

    -- Bars (werden beim Frame-Setup erzeugt)
    local hpBar    = frame.healthBar
    local powerBar = frame.powerBar

    -- defensiv: bars müssen existieren
    if not hpBar or not powerBar then
        return
    end

    -------------------------------------------------
    -- Health-Werte holen (können secret values sein)
    -------------------------------------------------
    local hp, hpMax
    if UnitHealth and UnitHealthMax then
        local ok1, v1 = pcall(UnitHealth, unit)
        if ok1 then hp = v1 end

        local ok2, v2 = pcall(UnitHealthMax, unit)
        if ok2 then hpMax = v2 end
    end

    if hp and hpMax then
        -- KEIN Vergleich / KEINE Arithmetik mit hp / hpMax
        hpBar:SetMinMaxValues(0, hpMax)
        hpBar:SetValue(hp)
    end

    -- Absorb / HealAbsorb-Balken an die aktuelle Max-HP anpassen
    UpdateAbsorbBars(frame, hpMax)

    -- Text nur über unsere Formatter (arbeiten mit %s, keine Mathe)
    frame.hpText:SetText(FormatHPText(unit, cfg.hpTextMode))

    -------------------------------------------------
    -- Power-Werte holen (ebenfalls secret values)
    -------------------------------------------------
    local pType, power, powerMax

    if UnitPowerType then
        local ok, pt = pcall(UnitPowerType, unit)
        if ok then pType = pt end
    end

    if pType and UnitPower and UnitPowerMax then
        local ok1, v1 = pcall(UnitPower, unit, pType)
        if ok1 then power = v1 end

        local ok2, v2 = pcall(UnitPowerMax, unit, pType)
        if ok2 then powerMax = v2 end
    end

        if cfg.manaEnabled and power and powerMax then
        powerBar:Show()
        powerBar:SetMinMaxValues(0, powerMax)
        powerBar:SetValue(power)

        frame.mpText:SetText(FormatPowerText(
            unit,
            cfg.mpTextMode or "BOTH",
            pType,
            power,
            powerMax
        ))
    else
        powerBar:Hide()
        frame.mpText:SetText("")
    end

end

-------------------------------------------------
-- Position speichern (nur Player1 / "player")
-------------------------------------------------
local function StoreCurrentPosition(frame)
    if not frame or not frame.GetPoint then
        return
    end

    -- Nur den Haupt-Player-Frame als Anker verwenden
    if frame.unit ~= "player" then
        return
    end

    -- Im Kampf keine Secure-Position ändern
    if InCombatLockdown and InCombatLockdown() then
        return
    end

    local cfg = GetPlayerConfig()
    local point, _, _, xOfs, yOfs = frame:GetPoint()

    cfg.anchorPoint = point or "CENTER"
    cfg.anchorX     = xOfs or 0
    cfg.anchorY     = yOfs or 0
end

-------------------------------------------------
-- Frame-Erzeugung
-------------------------------------------------
local function CreatePlayerEasyFrame(unit)
    if frames[unit] then return frames[unit] end

    -- Safety: nur Player1–Player4
    if not Player_UNIT_LOOKUP[unit] then
        return
    end
    local cfg = GetPlayerConfig()

    local f = CreateFrame("Button", "AvoidInterface_PlayerFrame_" .. unit, UIParent, "SecureUnitButtonTemplate")

    f.unit = unit

    local base = f:GetFrameLevel() or 1
    f:SetSize(cfg.width, cfg.height)
    f:SetFrameStrata("MEDIUM")
    f:SetMovable(true)
    f:SetClampedToScreen(true)

    -- Klicks: Links = Target, Rechts = Kontextmenü (Blizzard UnitPopup-Menü)
    f:RegisterForClicks("AnyUp")
    f:SetAttribute("type1", "target")
    f:SetAttribute("type2", "togglemenu")  -- NEU: öffnet das Unit-Kontextmenü
    f:SetAttribute("unit", unit)


    -- Hintergrund
    f.bg = f:CreateTexture(nil, "BACKGROUND")
    f.bg:SetAllPoints()
    f.bg:SetColorTexture(0, 0, 0, 0.6)

    -- HealthBar
    f.healthBar = CreateFrame("StatusBar", nil, f)
    f.healthBar:SetMinMaxValues(0, 1)
    f.healthBar:SetValue(1)
    f.healthBar:SetFrameLevel(base + 1)
    SetBarTexture(f.healthBar, cfg.hpTexture)
    f.healthBar.bg = f.healthBar:CreateTexture(nil, "BACKGROUND")
    f.healthBar.bg:SetAllPoints()
    f.healthBar.bg:SetColorTexture(0, 0, 0, 0.6)

    -- Absorb-Bar (Overlay auf der HealthBar, von rechts nach links – wie beim Player)
    f.absorbBar = CreateFrame("StatusBar", nil, f.healthBar)
    f.absorbBar:SetAllPoints(f.healthBar)
    f.absorbBar:SetStatusBarTexture("Interface\\Buttons\\WHITE8x8")
    f.absorbBar:SetStatusBarColor(0, 0, 0, 0.6)
    f.absorbBar:SetMinMaxValues(0, 1)
    f.absorbBar:SetValue(0)
    f.absorbBar:SetReverseFill(true)  -- von rechts nach links
    f.absorbBar:SetFrameLevel(f.healthBar:GetFrameLevel() + 1)
    f.absorbBar:Hide()

    -- HealAbsorb-Bar (verhindert Heilung, Overlay mit Schild-Textur – wie beim Player)
    f.healAbsorbBar = CreateFrame("StatusBar", nil, f.healthBar)
    f.healAbsorbBar:SetAllPoints(f.healthBar)
    f.healAbsorbBar:SetStatusBarTexture("Interface\\RAIDFRAME\\Shield-Overlay")
    f.healAbsorbBar:SetStatusBarColor(1, 0.8, 0, 0.8)
    f.healAbsorbBar:SetMinMaxValues(0, 1)
    f.healAbsorbBar:SetValue(0)
    f.healAbsorbBar:SetReverseFill(true)  -- ebenfalls von rechts nach links
    f.healAbsorbBar:SetFrameLevel(f.healthBar:GetFrameLevel() + 2)
    f.healAbsorbBar:Hide()

    -- PowerBar
    f.powerBar = CreateFrame("StatusBar", nil, f)
    f.powerBar:SetMinMaxValues(0, 1)
    f.powerBar:SetValue(1)
    f.powerBar:SetFrameLevel(base + 1)
    SetBarTexture(f.powerBar, cfg.mpTexture)

    f.powerBar.bg = f.powerBar:CreateTexture(nil, "BACKGROUND")
    f.powerBar.bg:SetAllPoints()
    f.powerBar.bg:SetColorTexture(0, 0, 0, 0.6)

    -- Separater Text-Layer über Bars & Border
    f.textLayer = CreateFrame("Frame", nil, f)
    f.textLayer:SetAllPoints(f)
    f.textLayer:SetFrameLevel(base + 3)

    -- NEU: Icon-Layer über dem Text-Layer
    f.iconLayer = CreateFrame("Frame", nil, f)
    f.iconLayer:SetAllPoints(f)
    f.iconLayer:SetFrameLevel(base + 4)

    -- Texte auf textLayer
    f.nameText  = f.textLayer:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.hpText    = f.textLayer:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.mpText    = f.textLayer:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.levelText = f.textLayer:CreateFontString(nil, "OVERLAY", "GameFontNormal")

    -- Icons jetzt auf iconLayer, damit sie über allem Text liegen
    f.combatIcon = f.iconLayer:CreateTexture(nil, "OVERLAY")
    f.combatIcon:SetTexture("Interface\\CharacterFrame\\UI-StateIcon")
    f.combatIcon:SetTexCoord(0.0, 0.5, 0.5, 1.0)
    f.combatIcon:Hide()

    f.restingIcon = f.iconLayer:CreateTexture(nil, "OVERLAY")
    f.restingIcon:SetTexture("Interface\\CharacterFrame\\UI-StateIcon")
    f.restingIcon:SetTexCoord(0.5, 1.0, 0.0, 0.5)
    f.restingIcon:Hide()

    f.leaderIcon = f.iconLayer:CreateTexture(nil, "OVERLAY")
    f.leaderIcon:SetTexture("Interface\\GroupFrame\\UI-Group-LeaderIcon")
    f.leaderIcon:Hide()

    f.raidIcon = f.iconLayer:CreateTexture(nil, "OVERLAY")
    f.raidIcon:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcons")
    f.raidIcon:Hide()

    -- Role-Icon (Tank/Heiler/DD)
    f.roleIcon = f.iconLayer:CreateTexture(nil, "OVERLAY")
    f.roleIcon:SetTexture("Interface\\LFGFrame\\UI-LFG-ICON-ROLES")
    f.roleIcon:Hide()

    -- Ready-Check-Icon (ready / notready / waiting)
    f.readyIcon = f.iconLayer:CreateTexture(nil, "OVERLAY")
    f.readyIcon:Hide()


    -- Auren-Buttons (werden dynamisch erzeugt)
    f.buffButtons   = {}
    f.debuffButtons = {}

    -- Mouse/Drag nur mit Player1 (ganzer Block)
    -- f:SetScript("OnMouseDown", function(self, button)
    --     if button == "LeftButton" and movingMode and self.unit == "Player" then
    --         self:StartMoving()
    --     end
    -- end)

    -- f:SetScript("OnMouseUp", function(self, button)
    --     if button == "LeftButton" and movingMode and self.unit == "Player" then
    --         self:StopMovingOrSizing()
    --         StoreCurrentPosition(self)
    --     end
    -- end)
    f:SetScript("OnMouseDown", function(self, button)
        if button == "LeftButton" and movingMode then
            self:StartMoving()
        end
    end)

    f:SetScript("OnMouseUp", function(self, button)
        if button == "LeftButton" and movingMode then
            self:StopMovingOrSizing()
            StoreCurrentPosition(self)
        end
    end)

    frames[unit] = f

    ApplyFrameLayout(f, cfg)
    UpdateHealthAndPower(f)
    UpdateAuras(f)   -- Buffs/Debuffs direkt initial setzen
    UpdateIcons(f)   -- und alle Icons direkt nach Frame-Erzeugung

    return f
end

-------------------------------------------------
-- EnsureFrames
--  KEIN :Show() / :Hide() mehr auf den Playerframes!
-------------------------------------------------
local function EnsureFrames()
    local cfg        = GetPlayerConfig()
    local inLockdown = IsInLockdown()

    -- Blizzard-Playerframe nur außerhalb von CombatLockdown anfassen
    if cfg.enabled and not inLockdown then
        HideBlizzardPlayer()
    end

    for _, unit in ipairs(Player_UNITS) do
        local exists = UnitExists and UnitExists(unit)
        local f      = frames[unit]

        if cfg.enabled and exists then
            -- neue SecureUnitButtons nur außerhalb von Lockdown erzeugen
            if not f and not inLockdown then
                f = CreatePlayerEasyFrame(unit)
                frames[unit] = f
            end

            if f then
                f:SetAlpha(cfg.alpha or 1)
                f:EnableMouse(true)
            end
        elseif f then
            -- "Verstecken", ohne :Hide()
            f:SetAlpha(0)
            f:EnableMouse(false)
        end
    end
end

-------------------------------------------------
-- EVENTS
-------------------------------------------------
local function OnEvent(self, event, arg1)
    local cfg = GetPlayerConfig()

    -- Modul abgeschaltet → Blizzard wieder aktiv, eigene Frames passiv
    if not cfg.enabled then
        RestoreBlizzardPlayer()
        return
    end

    -------------------------------------------------
    -- Initiales Setup
    -------------------------------------------------
    if event == "PLAYER_LOGIN" or event == "PLAYER_ENTERING_WORLD" then
        EnsureFrames()

        ForEachPlayerFrame(function(f)
            ApplyFrameLayout(f, cfg)
            UpdateHealthAndPower(f)
            UpdateAuras(f)
            UpdateIcons(f)
        end)

        UpdateAllRanges()
        return
    end

    -------------------------------------------------
    -- Unit-bezogene Events
    -------------------------------------------------
    if event == "UNIT_HEALTH"
        or event == "UNIT_MAXHEALTH"
        or event == "UNIT_POWER_UPDATE"
        or event == "UNIT_MAXPOWER"
        or event == "UNIT_DISPLAYPOWER"
        or event == "UNIT_LEVEL"
        or event == "UNIT_ABSORB_AMOUNT_CHANGED"
        or event == "UNIT_HEAL_ABSORB_AMOUNT_CHANGED" then

        if not Player_UNIT_LOOKUP[arg1] then return end
        local f = frames[arg1]
        if f then
            UpdateHealthAndPower(f)
        end
        return
    end

    if event == "UNIT_AURA" then
        if not Player_UNIT_LOOKUP[arg1] then return end
        local f = frames[arg1]
        if f then
            UpdateAuras(f)
        end
        return
    end

    -------------------------------------------------
    -- Status / Gruppe / Raidicons etc.
    -------------------------------------------------
    if event == "PLAYER_REGEN_DISABLED"
        or event == "PLAYER_REGEN_ENABLED"
        or event == "PLAYER_UPDATE_RESTING"
        or event == "GROUP_ROSTER_UPDATE"
        or event == "PARTY_LEADER_CHANGED"
        or event == "RAID_TARGET_UPDATE" then

        ForEachPlayerFrame(function(f)
            UpdateIcons(f)
        end)
        return
    end

    -------------------------------------------------
    -- Tod / Geist / Wiederbelebt
    -------------------------------------------------
    if event == "PLAYER_DEAD"
        or event == "PLAYER_ALIVE"
        or event == "PLAYER_UNGHOST" then

        ForEachPlayerFrame(function(f)
            UpdateHealthAndPower(f)
            UpdateIcons(f)
        end)
        return
    end
end

-------------------------------------------------
-- EVENTFRAME
-------------------------------------------------
local function EnsureEventFrame()
    if eventFrame then return end

    eventFrame = CreateFrame("Frame")

    -- Initiale Login/Zone Events
    eventFrame:RegisterEvent("PLAYER_LOGIN")
    eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")

    -- Unit-Events für alle Player_UNITS (aktuell nur "player")
    for _, unit in ipairs(Player_UNITS) do
        eventFrame:RegisterUnitEvent("UNIT_HEALTH", unit)
        eventFrame:RegisterUnitEvent("UNIT_MAXHEALTH", unit)
        eventFrame:RegisterUnitEvent("UNIT_POWER_UPDATE", unit)
        eventFrame:RegisterUnitEvent("UNIT_MAXPOWER", unit)
        eventFrame:RegisterUnitEvent("UNIT_DISPLAYPOWER", unit)
        eventFrame:RegisterUnitEvent("UNIT_LEVEL", unit)
        eventFrame:RegisterUnitEvent("UNIT_AURA", unit)
        eventFrame:RegisterUnitEvent("UNIT_ABSORB_AMOUNT_CHANGED", unit)
        eventFrame:RegisterUnitEvent("UNIT_HEAL_ABSORB_AMOUNT_CHANGED", unit)
    end

    -- Tod / Geist / wiederbelebt
    eventFrame:RegisterEvent("PLAYER_DEAD")
    eventFrame:RegisterEvent("PLAYER_ALIVE")
    eventFrame:RegisterEvent("PLAYER_UNGHOST")

    -- Kampfstatus / Gruppe / Leader / Raid-Target
    eventFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
    eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
    eventFrame:RegisterEvent("PLAYER_UPDATE_RESTING")
    eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
    eventFrame:RegisterEvent("PARTY_LEADER_CHANGED")
    eventFrame:RegisterEvent("RAID_TARGET_UPDATE")

    eventFrame:SetScript("OnEvent", OnEvent)
end

-------------------------------------------------
-- MODUL-API
-------------------------------------------------
function M.UpdateAll()
    local cfg = GetPlayerConfig()

    ForEachPlayerFrame(function(f)
        ApplyFrameLayout(f, cfg)
        UpdateHealthAndPower(f)
        UpdateAuras(f)
        UpdateIcons(f)
    end)

    UpdateAllRanges()
end

function M.Enable()
    local cfg = GetPlayerConfig()
    if not cfg.enabled then
        M.Disable()
        return
    end

    EnsureEventFrame()
    EnsureFrames()
    M.UpdateAll()
end

function M.Refresh()
    local cfg = GetPlayerConfig()
    if not cfg.enabled then
        M.Disable()
        return
    end

    EnsureEventFrame()
    EnsureFrames()
    M.UpdateAll()
end

function M.Disable()
    if eventFrame then
        eventFrame:UnregisterAllEvents()
        eventFrame:SetScript("OnEvent", nil)
        eventFrame = nil
    end

    -- Frames passiv schalten
    ForEachPlayerFrame(function(f)
        f:SetAlpha(0)
        f:EnableMouse(false)
    end)

    RestoreBlizzardPlayer()
end

function M.StartMovingMode()
    movingMode = true
    local cfg = GetPlayerConfig()
    cfg.movable = true

    ForEachPlayerFrame(function(f)
        f:EnableMouse(true)
    end)
end

function M.StopMovingMode()
    movingMode = false
    local cfg = GetPlayerConfig()
    cfg.movable = false

    ForEachPlayerFrame(function(f)
        f:EnableMouse(true)
        StoreCurrentPosition(f)
    end)
end

function M.ApplyLayout()
    M.UpdateAll()
end

-------------------------------------------------
-- REGISTRIERUNG BEIM CORE
-------------------------------------------------
if AI and AI.RegisterFrameType then
    AI.RegisterFrameType("player", M)
else
    local temp = CreateFrame("Frame")
    temp:RegisterEvent("ADDON_LOADED")
    temp:SetScript("OnEvent", function(self, event, addon)
        if addon == "Avoid_Interface_Core" and AI and AI.RegisterFrameType then
            AI.RegisterFrameType("player", M)
            self:UnregisterAllEvents()
            self:SetScript("OnEvent", nil)
        end
    end)
end
