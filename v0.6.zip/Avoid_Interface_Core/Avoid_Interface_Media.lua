-- Avoid_Interface_Media.lua
-- Zentrale Registrierung eigener Medien (Fonts, später evtl. auch Texturen/Sounds)

local addonName, ns = ...

-- SharedMedia holen (falls vorhanden)
local LSM = LibStub and LibStub("LibSharedMedia-3.0", true)
if not LSM then
    -- Kein SharedMedia installiert → einfach leise aussteigen
    return
end

-- Basis-Pfad zu deinen Font-Dateien
-- Passe diesen Pfad an deine Struktur an!
local FONT_PATH = "Interface\\AddOns\\Avoid_Interface_Core\\media\\fonts\\"

--[[ 
    Font-Liste:
    KEY   = Anzeigename im Dropdown
    VALUE = Dateiname im media\fonts-Ordner
    → Registriert als: LSM:Register("font", KEY, FONT_PATH .. VALUE)
]]
local AI_Media_Fonts = {
    ["Accidental Presidency"] = "Accidental Presidency.ttf",
    ["accidental_pres"] = "accidental_pres.ttf",
    ["ActionMan"] = "ActionMan.ttf",
    ["Carlito-Regular"] = "Carlito-Regular.ttf",
    ["ContinuumMedium"] = "ContinuumMedium.ttf",
    ["DieDieDie"] = "DieDieDie.ttf",
    ["ElMessiri-VariableFont_wght"] = "ElMessiri-VariableFont_wght.ttf",
    ["Expressway"] = "Expressway.TTF",
    ["FiraMono-Medium"] = "FiraMono-Medium.ttf",
    ["FiraSans-Heavy"] = "FiraSans-Heavy.ttf",
    ["FiraSans-Medium"] = "FiraSans-Medium.ttf",
    ["FiraSansCondensed-Heavy"] = "FiraSansCondensed-Heavy.ttf",
    ["FiraSansCondensed-Medium"] = "FiraSansCondensed-Medium.ttf",
    ["FORCED SQUARE"] = "FORCED SQUARE.ttf",
    ["francois"] = "francois.ttf",
    ["HARRYP__"] = "HARRYP__.TTF",
    ["Homespun"] = "Homespun.ttf",
    ["Invisible"] = "Invisible.ttf",
    ["Montserrat-Bold"] = "Montserrat-Bold.ttf",
    ["Montserrat-Italic"] = "Montserrat-Italic.ttf",
    ["Montserrat-Medium"] = "Montserrat-Medium.ttf",
    ["Montserrat-Regular"] = "Montserrat-Regular.ttf",
    ["NotoNaskhArabic-Regular"] = "NotoNaskhArabic-Regular.ttf",
    ["Nueva Std Cond"] = "Nueva Std Cond.ttf",
    ["Oswald-Regular"] = "Oswald-Regular.ttf",
    ["PTSansNarrow-Bold"] = "PTSansNarrow-Bold.ttf",
    ["PTSansNarrow-Regular"] = "PTSansNarrow-Regular.ttf",
    ["PTSansNarrow"] = "PTSansNarrow.ttf",
    ["Quazii"] = "Quazii.ttf",
    ["Roboto-Medium"] = "Roboto-Medium.ttf",
    ["Roboto-Regular"] = "Roboto-Regular.ttf",
    ["roboto"] = "roboto.ttf",
    ["TrashHand"] = "TrashHand.TTF",
    -- weitere:
    -- ["AI Something"]    = "Something.ttf",
}

-- Optional im Namespace ablegen, falls du später im UI drauf zugreifen willst
ns = ns or {}
ns.AI_Media_Fonts = AI_Media_Fonts

-- Alle Fonts bei SharedMedia registrieren
for key, fileName in pairs(AI_Media_Fonts) do
    local fullPath = FONT_PATH .. fileName
    LSM:Register("font", key, fullPath)
end
